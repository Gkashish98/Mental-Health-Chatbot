import { useState, useCallback } from 'react';
import { Message, ChatSession } from '../types';

export const useChat = () => {
  const [sessions, setSessions] = useState<ChatSession[]>([]);
  const [activeSessionId, setActiveSessionId] = useState<string | null>(null);
  const [isTyping, setIsTyping] = useState(false);

  const activeSession = sessions.find(s => s.id === activeSessionId);

  const createNewSession = useCallback(() => {
    const newSession: ChatSession = {
      id: Date.now().toString(),
      title: 'New Conversation',
      messages: [],
      createdAt: new Date(),
      updatedAt: new Date()
    };

    setSessions(prev => [newSession, ...prev]);
    setActiveSessionId(newSession.id);
    return newSession;
  }, []);

  const addMessage = useCallback((message: Message) => {
    if (!activeSessionId) {
      const newSession = createNewSession();
      setSessions(prev => prev.map(session => 
        session.id === newSession.id 
          ? {
              ...session,
              messages: [message],
              title: message.text.slice(0, 50) + (message.text.length > 50 ? '...' : ''),
              updatedAt: new Date()
            }
          : session
      ));
    } else {
      setSessions(prev => prev.map(session => 
        session.id === activeSessionId 
          ? {
              ...session,
              messages: [...session.messages, message],
              title: session.messages.length === 0 
                ? message.text.slice(0, 50) + (message.text.length > 50 ? '...' : '')
                : session.title,
              updatedAt: new Date()
            }
          : session
      ));
    }
  }, [activeSessionId, createNewSession]);

  const selectSession = useCallback((sessionId: string) => {
    setActiveSessionId(sessionId);
  }, []);

  const deleteSession = useCallback((sessionId: string) => {
    setSessions(prev => prev.filter(s => s.id !== sessionId));
    if (activeSessionId === sessionId) {
      setActiveSessionId(null);
    }
  }, [activeSessionId]);

  const startNewChat = useCallback(() => {
    createNewSession();
  }, [createNewSession]);

  return {
    sessions,
    activeSession,
    activeSessionId,
    isTyping,
    setIsTyping,
    addMessage,
    selectSession,
    deleteSession,
    startNewChat
  };
};