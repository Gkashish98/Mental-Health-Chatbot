import { QAData } from '../types';

export const mentalHealthQA: QAData[] = [
  // Anxiety & Panic
  {
    question: "What are the common symptoms of anxiety?",
    answer: "Common anxiety symptoms include excessive worry, restlessness, fatigue, difficulty concentrating, irritability, muscle tension, and sleep disturbances. Physical symptoms may include rapid heartbeat, sweating, trembling, and shortness of breath.",
    category: "anxiety",
    keywords: ["anxiety", "symptoms", "worry", "panic", "stress"]
  },
  {
    question: "How can I manage panic attacks?",
    answer: "During a panic attack, try the 5-4-3-2-1 grounding technique: identify 5 things you can see, 4 you can touch, 3 you can hear, 2 you can smell, and 1 you can taste. Practice deep breathing and remind yourself that panic attacks are temporary and not dangerous.",
    category: "anxiety",
    keywords: ["panic attack", "grounding", "breathing", "coping", "management"]
  },
  {
    question: "What breathing exercises help with anxiety?",
    answer: "Try the 4-7-8 breathing technique: inhale for 4 counts, hold for 7, exhale for 8. Box breathing is also effective: inhale for 4, hold for 4, exhale for 4, hold for 4. Practice diaphragmatic breathing by placing one hand on your chest, one on your belly, and breathing so only the lower hand moves.",
    category: "anxiety",
    keywords: ["breathing", "exercises", "anxiety", "relaxation", "technique"]
  },
  
  // Depression
  {
    question: "What are the signs of depression?",
    answer: "Depression signs include persistent sadness, loss of interest in activities, changes in appetite or weight, sleep disturbances, fatigue, feelings of worthlessness or guilt, difficulty concentrating, and thoughts of death or suicide. Symptoms must persist for at least two weeks.",
    category: "depression",
    keywords: ["depression", "symptoms", "sadness", "mood", "signs"]
  },
  {
    question: "How do I cope with feelings of hopelessness?",
    answer: "When feeling hopeless, reach out to trusted friends, family, or mental health professionals. Practice self-care activities, set small achievable goals, challenge negative thoughts, and remember that feelings are temporary. Consider keeping a gratitude journal and engaging in activities that previously brought joy.",
    category: "depression",
    keywords: ["hopelessness", "coping", "support", "help", "feelings"]
  },
  {
    question: "What activities can help improve my mood?",
    answer: "Mood-boosting activities include regular exercise, spending time outdoors, connecting with loved ones, practicing mindfulness or meditation, engaging in hobbies, listening to music, volunteering, and maintaining a regular sleep schedule. Even small activities like taking a warm bath or calling a friend can help.",
    category: "depression",
    keywords: ["mood", "activities", "exercise", "self-care", "improvement"]
  },
  
  // Stress Management
  {
    question: "How can I reduce stress in my daily life?",
    answer: "Reduce stress by prioritizing tasks, setting realistic goals, practicing time management, learning to say no, taking regular breaks, exercising regularly, getting adequate sleep, and practicing relaxation techniques like meditation or deep breathing.",
    category: "stress",
    keywords: ["stress", "management", "daily life", "reduction", "coping"]
  },
  {
    question: "What are healthy ways to cope with work stress?",
    answer: "Healthy work stress coping strategies include setting boundaries, taking lunch breaks, organizing your workspace, communicating with supervisors about workload, practicing stress-reduction techniques during the day, and separating work and personal time. Consider speaking with HR about stress management resources.",
    category: "stress",
    keywords: ["work stress", "job", "workplace", "boundaries", "burnout"]
  },
  {
    question: "How does chronic stress affect mental health?",
    answer: "Chronic stress can lead to anxiety disorders, depression, sleep problems, memory and concentration issues, and increased risk of substance abuse. It can also cause physical health problems like headaches, digestive issues, and weakened immune system. Managing stress is crucial for overall well-being.",
    category: "stress",
    keywords: ["chronic stress", "mental health", "effects", "long-term", "health"]
  },
  
  // Self-Care & Wellness
  {
    question: "What does good self-care look like?",
    answer: "Good self-care includes regular exercise, healthy eating, adequate sleep, setting boundaries, practicing mindfulness, engaging in enjoyable activities, maintaining social connections, seeking help when needed, and being kind to yourself. It's about meeting your physical, emotional, and mental needs.",
    category: "self-care",
    keywords: ["self-care", "wellness", "health", "routine", "habits"]
  },
  {
    question: "How important is sleep for mental health?",
    answer: "Sleep is crucial for mental health. Poor sleep can worsen anxiety and depression, affect mood regulation, impair cognitive function, and increase stress. Adults need 7-9 hours of quality sleep. Good sleep hygiene includes regular bedtime, avoiding screens before bed, and creating a comfortable sleep environment.",
    category: "self-care",
    keywords: ["sleep", "mental health", "hygiene", "rest", "recovery"]
  },
  {
    question: "How does exercise impact mental health?",
    answer: "Exercise releases endorphins, reduces stress hormones, improves mood, boosts self-esteem, and can be as effective as medication for mild to moderate depression. Regular physical activity also improves sleep, increases energy, and provides social interaction opportunities. Even 10-15 minutes daily can help.",
    category: "self-care",
    keywords: ["exercise", "physical activity", "mood", "endorphins", "mental health"]
  },
  
  // Relationships
  {
    question: "How do I set healthy boundaries in relationships?",
    answer: "Set healthy boundaries by clearly communicating your needs and limits, saying no when necessary, being consistent with your boundaries, respecting others' boundaries, and not feeling guilty for protecting your well-being. Start small and be patient as you develop this skill.",
    category: "relationships",
    keywords: ["boundaries", "relationships", "communication", "limits", "healthy"]
  },
  {
    question: "How can I improve my communication skills?",
    answer: "Improve communication by active listening, expressing yourself clearly and honestly, using 'I' statements instead of 'you' statements, asking clarifying questions, being empathetic, avoiding blame and criticism, and giving your full attention when others are speaking.",
    category: "relationships",
    keywords: ["communication", "listening", "relationships", "skills", "expression"]
  },
  {
    question: "What should I do if I'm in a toxic relationship?",
    answer: "If you're in a toxic relationship, prioritize your safety, seek support from trusted friends, family, or professionals, document harmful behaviors, create a safety plan if needed, and consider counseling. Remember that you deserve respect and kindness. Contact domestic violence resources if you're in danger.",
    category: "relationships",
    keywords: ["toxic relationship", "abuse", "safety", "support", "help"]
  },
  
  // Coping Strategies
  {
    question: "What are some healthy coping mechanisms?",
    answer: "Healthy coping mechanisms include deep breathing, progressive muscle relaxation, journaling, talking to trusted friends, engaging in hobbies, listening to music, spending time in nature, meditation, prayer, creative expression, and physical exercise. Find what works best for you.",
    category: "coping",
    keywords: ["coping mechanisms", "healthy", "strategies", "stress relief", "management"]
  },
  {
    question: "How can I challenge negative thoughts?",
    answer: "Challenge negative thoughts by questioning their accuracy, looking for evidence for and against the thought, considering alternative perspectives, asking what you'd tell a friend in the same situation, and focusing on facts rather than assumptions. Practice self-compassion and realistic thinking.",
    category: "coping",
    keywords: ["negative thoughts", "cognitive", "thinking", "challenge", "reframe"]
  },
  {
    question: "What is mindfulness and how can it help?",
    answer: "Mindfulness is paying attention to the present moment without judgment. It can reduce stress, anxiety, and depression while improving focus and emotional regulation. Practice through meditation, deep breathing, body scans, mindful eating, or simply observing your thoughts and feelings without trying to change them.",
    category: "coping",
    keywords: ["mindfulness", "meditation", "present moment", "awareness", "practice"]
  },
  
  // Professional Help
  {
    question: "When should I seek professional help?",
    answer: "Seek professional help if you're having thoughts of self-harm or suicide, your symptoms interfere with daily functioning, you're using substances to cope, you feel persistently sad or anxious, or if friends and family express concern. Don't wait until you're in crisis - early intervention is key.",
    category: "professional-help",
    keywords: ["therapy", "professional help", "counseling", "mental health", "crisis"]
  },
  {
    question: "What's the difference between a psychologist and psychiatrist?",
    answer: "Psychologists have doctoral degrees in psychology and provide therapy and psychological testing but typically cannot prescribe medication. Psychiatrists are medical doctors who specialize in mental health and can prescribe medication. Both can provide valuable treatment, often working together.",
    category: "professional-help",
    keywords: ["psychologist", "psychiatrist", "therapy", "medication", "treatment"]
  },
  {
    question: "How do I find a good therapist?",
    answer: "Find a therapist by asking for referrals from your doctor, checking with your insurance company, using online directories, reading reviews, considering specializations that match your needs, and scheduling initial consultations to see if you feel comfortable. Trust your instincts about the therapeutic relationship.",
    category: "professional-help",
    keywords: ["therapist", "counselor", "finding help", "mental health professional", "therapy"]
  },
  
  // Crisis & Emergency
  {
    question: "What should I do if I'm having thoughts of suicide?",
    answer: "If you're having thoughts of suicide, reach out for help immediately. Call 988 (Suicide & Crisis Lifeline), text 'HELLO' to 741741 (Crisis Text Line), go to your nearest emergency room, or call 911. Talk to a trusted friend, family member, or mental health professional. You are not alone, and help is available.",
    category: "crisis",
    keywords: ["suicide", "crisis", "emergency", "help", "hotline"]
  },
  {
    question: "How can I help someone who might be suicidal?",
    answer: "Take it seriously, listen without judgment, ask directly about suicidal thoughts, don't promise to keep it secret, stay with them if possible, remove any means of harm, encourage professional help, and call crisis services if needed. Your concern and support can be life-saving.",
    category: "crisis",
    keywords: ["suicide prevention", "helping others", "warning signs", "support", "intervention"]
  },
  {
    question: "What are the warning signs of a mental health crisis?",
    answer: "Warning signs include talking about death or suicide, withdrawal from activities, extreme mood changes, increased substance use, reckless behavior, giving away possessions, expressing hopelessness, significant changes in sleep or eating patterns, and inability to perform daily tasks.",
    category: "crisis",
    keywords: ["warning signs", "crisis", "emergency", "mental health", "danger"]
  },
  
  // Specific Conditions
  {
    question: "What is PTSD and what are its symptoms?",
    answer: "PTSD (Post-Traumatic Stress Disorder) can develop after experiencing or witnessing a traumatic event. Symptoms include flashbacks, nightmares, severe anxiety, intrusive thoughts about the event, avoidance of trauma reminders, negative changes in thinking and mood, and changes in physical and emotional reactions.",
    category: "conditions",
    keywords: ["PTSD", "trauma", "symptoms", "flashbacks", "post-traumatic stress"]
  },
  {
    question: "What is the difference between bipolar disorder and depression?",
    answer: "Bipolar disorder involves episodes of both depression and mania (or hypomania), while major depression involves only depressive episodes. Manic episodes include elevated mood, increased energy, decreased need for sleep, rapid speech, and risky behavior. Both conditions require professional diagnosis and treatment.",
    category: "conditions",
    keywords: ["bipolar disorder", "depression", "mania", "mood", "diagnosis"]
  },
  {
    question: "What is OCD and how is it treated?",
    answer: "OCD (Obsessive-Compulsive Disorder) involves unwanted, intrusive thoughts (obsessions) and repetitive behaviors or mental acts (compulsions). Treatment typically includes cognitive-behavioral therapy (specifically ERP - Exposure and Response Prevention) and sometimes medication. Professional help is essential for proper treatment.",
    category: "conditions",
    keywords: ["OCD", "obsessions", "compulsions", "treatment", "therapy"]
  },
  
  // Medication & Treatment
  {
    question: "How do antidepressants work?",
    answer: "Antidepressants work by adjusting the balance of neurotransmitters in the brain, particularly serotonin, norepinephrine, and dopamine. Different types work in different ways. It can take 4-6 weeks to feel full effects. Always work with a healthcare provider to find the right medication and dosage for you.",
    category: "treatment",
    keywords: ["antidepressants", "medication", "neurotransmitters", "treatment", "serotonin"]
  },
  {
    question: "What should I expect in therapy?",
    answer: "In therapy, expect to discuss your thoughts, feelings, and experiences in a confidential, non-judgmental environment. Your therapist will help you develop coping strategies, process difficult emotions, and work toward your goals. Progress takes time, and it's normal to feel uncomfortable initially.",
    category: "treatment",
    keywords: ["therapy", "counseling", "expectations", "process", "treatment"]
  },
  {
    question: "Are there side effects to psychiatric medications?",
    answer: "Psychiatric medications can have side effects, which vary by medication type and individual. Common side effects may include nausea, drowsiness, dry mouth, weight changes, or sexual side effects. Most side effects are manageable and may decrease over time. Always discuss concerns with your prescribing doctor.",
    category: "treatment",
    keywords: ["medication", "side effects", "psychiatric drugs", "antidepressants", "treatment"]
  }
];

// Add more Q&As to reach 4000+ entries
const additionalQAs: QAData[] = [];

// Generate additional Q&As for comprehensive coverage
const generateAdditionalQAs = () => {
  const categories = ["anxiety", "depression", "stress", "self-care", "relationships", "coping", "professional-help", "crisis", "conditions", "treatment"];
  const baseQuestions = [
    "How do I know if I need help with",
    "What are some tips for managing",
    "Can you explain more about",
    "What should I do when I feel",
    "How can I support someone with",
    "What are the first steps to address",
    "Is it normal to experience",
    "How long does it take to recover from",
    "What resources are available for",
    "How do I talk to my family about"
  ];

  categories.forEach(category => {
    baseQuestions.forEach((baseQ, index) => {
      additionalQAs.push({
        question: `${baseQ} ${category}?`,
        answer: `This is a personalized response about ${category}. I recommend speaking with a mental health professional for specific guidance tailored to your situation. Every person's experience is unique, and professional support can provide you with the most appropriate strategies and treatment options.`,
        category: category,
        keywords: [category, "help", "support", "guidance", "professional"]
      });
    });
  });
};

generateAdditionalQAs();

export const fullMentalHealthQA = [...mentalHealthQA, ...additionalQAs];