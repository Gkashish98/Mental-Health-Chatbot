import React, { useState } from 'react';
import { WelcomeScreen } from './components/WelcomeScreen';
import { Sidebar } from './components/Sidebar';
import { ChatInterface } from './components/ChatInterface';
import { useChat } from './hooks/useChat';

function App() {
  const [showWelcome, setShowWelcome] = useState(true);
  const {
    sessions,
    activeSession,
    activeSessionId,
    isTyping,
    setIsTyping,
    addMessage,
    selectSession,
    deleteSession,
    startNewChat
  } = useChat();

  const handleGetStarted = () => {
    setShowWelcome(false);
    startNewChat();
  };

  if (showWelcome) {
    return <WelcomeScreen onGetStarted={handleGetStarted} />;
  }

  return (
    <div className="h-screen flex bg-gray-100">
      <Sidebar
        sessions={sessions}
        activeSessionId={activeSessionId}
        onNewChat={startNewChat}
        onSelectSession={selectSession}
        onDeleteSession={deleteSession}
      />
      
      <div className="flex-1 p-4">
        <ChatInterface
          messages={activeSession?.messages || []}
          onNewMessage={addMessage}
          isTyping={isTyping}
          setIsTyping={setIsTyping}
        />
      </div>
    </div>
  );
}

export default App;