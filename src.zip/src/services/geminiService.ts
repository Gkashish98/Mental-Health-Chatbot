import { GoogleGenerativeAI } from "@google/generative-ai";

const API_KEY = import.meta.env.VITE_GEMINI_API_KEY || ""; // Keep key in .env

// Initialize the Gemini client
const genAI = new GoogleGenerativeAI(API_KEY);

export class GeminiService {
  // ✅ Setting primary model to the most capable/advanced stable model
  private primaryModel = "gemini-2.5-flash";
  // ✅ Setting fallback model to the fast and cost-effective stable model
  private fallbackModel = "gemini-2.5-flash";

  async getChatResponse(prompt: string, history: string[] = []): Promise<string> {
    try {
      // 1. Attempt generation with the primary, high-capability model (Pro)
      return await this.generateWithModel(this.primaryModel, prompt, history);
    } catch (error: any) {
      console.error(`Primary model (${this.primaryModel}) failed:`, error);

      // Check if it's a quota error (429) or other common API error
      if (error.message?.includes("429") || error.message?.includes("Quota exceeded") || error.message?.includes("API_ERROR")) {
        console.warn(`⚠️ Primary model failed (potential quota/API issue). Falling back to ${this.fallbackModel}...`);
        try {
          // 2. Attempt generation with the fallback model (Flash)
          return await this.generateWithModel(this.fallbackModel, prompt, history);
        } catch (fallbackError) {
          console.error("Fallback model also failed:", fallbackError);
          // 3. If both fail, throw a user-friendly error
          throw new Error("Both Gemini models failed. Please try again later.");
        }
      }

      throw error; // rethrow other errors
    }
  }

  private async generateWithModel(modelName: string, prompt: string, history: string[]): Promise<string> {
    // ✅ Correctly get the model
    const model = genAI.getGenerativeModel({ model: modelName });

    // ✅ Build chat with history
    const chat = model.startChat({
      history: history.map((h, idx) => ({
        role: idx % 2 === 0 ? "user" : "model", // alternate roles properly
        parts: [{ text: h }],
      })),
    });

    // ✅ Send prompt
    const result = await chat.sendMessage(prompt);
    const response = result.response?.text();

    return response || "I’m here, but I couldn’t generate a response right now.";
  }
}

// ✅ Export singleton service
export const geminiService = new GeminiService();
