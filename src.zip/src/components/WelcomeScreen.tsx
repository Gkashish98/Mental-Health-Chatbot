import React from 'react';
import { Heart, Shield, Clock, Users } from 'lucide-react';

interface WelcomeScreenProps {
  onGetStarted: () => void;
}

export const WelcomeScreen: React.FC<WelcomeScreenProps> = ({ onGetStarted }) => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-teal-50">
      <div className="container mx-auto px-4 py-12">
        {/* Header */}
        <div className="text-center mb-16">
          <div className="flex items-center justify-center space-x-3 mb-6">
            <div className="w-16 h-16 bg-gradient-to-r from-blue-500 to-teal-500 rounded-2xl flex items-center justify-center">
              <Heart className="w-8 h-8 text-white" />
            </div>
            <h1 className="text-4xl font-bold text-gray-800">MindSpace</h1>
          </div>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Your compassionate AI companion for mental health support, available 24/7 
            with evidence-based guidance and caring conversation.
          </p>
        </div>

        {/* Features */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mb-16">
          {[
            {
              icon: Heart,
              title: "Compassionate Support",
              description: "Get empathetic, non-judgmental support whenever you need it"
            },
            {
              icon: Shield,
              title: "Safe & Private",
              description: "Your conversations are confidential and secure"
            },
            {
              icon: Clock,
              title: "24/7 Availability",
              description: "Mental health support doesn't wait for business hours"
            },
            {
              icon: Users,
              title: "Professional Resources",
              description: "Connect with mental health professionals when needed"
            }
          ].map((feature, index) => (
            <div key={index} className="bg-white p-6 rounded-xl shadow-sm border border-gray-100 hover:shadow-md transition-shadow">
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-4">
                <feature.icon className="w-6 h-6 text-blue-600" />
              </div>
              <h3 className="text-lg font-semibold text-gray-800 mb-2">{feature.title}</h3>
              <p className="text-gray-600">{feature.description}</p>
            </div>
          ))}
        </div>

        {/* CTA Section */}
        <div className="text-center mb-16">
          <div className="bg-white p-8 rounded-2xl shadow-lg border border-gray-100 max-w-2xl mx-auto">
            <h2 className="text-2xl font-bold text-gray-800 mb-4">Ready to Start?</h2>
            <p className="text-gray-600 mb-6">
              Take the first step towards better mental health. Our AI companion is here 
              to listen, support, and guide you with evidence-based strategies.
            </p>
            <button
              onClick={onGetStarted}
              className="px-8 py-3 bg-gradient-to-r from-blue-500 to-teal-500 text-white font-semibold rounded-lg hover:from-blue-600 hover:to-teal-600 transition-all duration-200 transform hover:scale-105"
            >
              Start Your Journey
            </button>
          </div>
        </div>

        {/* Important Notice */}
        <div className="bg-amber-50 border border-amber-200 rounded-xl p-6 max-w-4xl mx-auto">
          <h3 className="text-lg font-semibold text-amber-800 mb-2">Important Notice</h3>
          <p className="text-amber-700">
            This AI chatbot provides supportive conversation and information but is not a substitute 
            for professional mental health care. In case of emergency, please contact 911 or the 
            Suicide & Crisis Lifeline at 988. Always consult with licensed mental health professionals 
            for personalized treatment and diagnosis.
          </p>
        </div>

        {/* Crisis Resources */}
        <div className="mt-12 text-center">
          <h3 className="text-lg font-semibold text-gray-800 mb-4">Crisis Resources</h3>
          <div className="flex flex-wrap justify-center gap-6 text-sm">
            <div className="bg-red-50 px-4 py-2 rounded-lg border border-red-200">
              <strong>Emergency:</strong> 911
            </div>
            <div className="bg-red-50 px-4 py-2 rounded-lg border border-red-200">
              <strong>Suicide & Crisis Lifeline:</strong> 988
            </div>
            <div className="bg-red-50 px-4 py-2 rounded-lg border border-red-200">
              <strong>Crisis Text Line:</strong> Text HOME to 741741
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};