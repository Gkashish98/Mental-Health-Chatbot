import React from 'react';
import { Plus, MessageSquare, Heart, Phone, ExternalLink, Settings, HelpCircle } from 'lucide-react';
import { ChatSession } from '../types';

interface SidebarProps {
  sessions: ChatSession[];
  activeSessionId: string | null;
  onNewChat: () => void;
  onSelectSession: (sessionId: string) => void;
  onDeleteSession: (sessionId: string) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  sessions,
  activeSessionId,
  onNewChat,
  onSelectSession,
  onDeleteSession
}) => {
  const crisisResources = [
    {
      name: "Suicide & Crisis Lifeline",
      number: "988",
      description: "24/7 free and confidential support"
    },
    {
      name: "Crisis Text Line",
      number: "Text HOME to 741741",
      description: "Free, 24/7 crisis support via text"
    },
    {
      name: "NAMI Helpline",
      number: "1-800-950-NAMI",
      description: "Information and support"
    }
  ];

  return (
    <div className="w-80 bg-white border-r border-gray-200 h-full flex flex-col">
      {/* Header */}
      <div className="p-6 border-b border-gray-200">
        <div className="flex items-center space-x-3 mb-4">
          <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-teal-500 rounded-lg flex items-center justify-center">
            <Heart className="w-5 h-5 text-white" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-gray-800">MindSpace</h1>
            <p className="text-sm text-gray-600">Mental Health Support</p>
          </div>
        </div>
        
        <button
          onClick={onNewChat}
          className="w-full flex items-center space-x-2 px-4 py-3 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors"
        >
          <Plus className="w-4 h-4" />
          <span>New Conversation</span>
        </button>
      </div>

      {/* Chat Sessions */}
      <div className="flex-1 overflow-y-auto p-4">
        <h3 className="text-sm font-semibold text-gray-700 mb-3">Recent Conversations</h3>
        <div className="space-y-2">
          {sessions.map((session) => (
            <div
              key={session.id}
              className={`group p-3 rounded-lg cursor-pointer transition-colors ${
                activeSessionId === session.id
                  ? 'bg-blue-50 border-l-4 border-blue-500'
                  : 'hover:bg-gray-50'
              }`}
              onClick={() => onSelectSession(session.id)}
            >
              <div className="flex items-start space-x-3">
                <MessageSquare className="w-4 h-4 text-gray-400 mt-1" />
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-gray-800 truncate">
                    {session.title}
                  </p>
                  <p className="text-xs text-gray-500 mt-1">
                    {session.messages.length} messages
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Crisis Resources */}
      <div className="p-4 border-t border-gray-200 bg-red-50">
        <h3 className="text-sm font-semibold text-red-800 mb-3 flex items-center">
          <Phone className="w-4 h-4 mr-2" />
          Crisis Resources
        </h3>
        <div className="space-y-3">
          {crisisResources.map((resource, index) => (
            <div key={index} className="text-sm">
              <p className="font-medium text-red-800">{resource.name}</p>
              <p className="font-mono text-red-700">{resource.number}</p>
              <p className="text-red-600 text-xs">{resource.description}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Bottom Links */}
      <div className="p-4 border-t border-gray-200 space-y-2">
        <a
          href="#"
          className="flex items-center space-x-2 text-sm text-gray-600 hover:text-gray-800"
        >
          <HelpCircle className="w-4 h-4" />
          <span>Help & Support</span>
          <ExternalLink className="w-3 h-3" />
        </a>
        <a
          href="#"
          className="flex items-center space-x-2 text-sm text-gray-600 hover:text-gray-800"
        >
          <Settings className="w-4 h-4" />
          <span>Settings</span>
        </a>
      </div>
    </div>
  );
};